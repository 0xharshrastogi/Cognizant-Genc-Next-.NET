import { Courses } from "./course"
export const lcourse:Courses[]=[
    {id:1,name:"Angular",price:5000,desc:"Front End Framework"},
    {id:2,name:"JAVA",price:7000,desc:"Desktop Application"},
    {id:3,name:"PHP",price:8000,desc:"Web App Development"},
    {id:4,name:"Flutter",price:9000,desc:"Mobile App Development"},
    {id:5,name:"Python",price:6000,desc:"Machine Learning"},
    
];